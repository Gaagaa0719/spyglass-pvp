import "./commands/index.js";
import "./items/index.js";
import "./Game.js";
console.log("Loaded");
