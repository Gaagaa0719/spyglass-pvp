export class ArrayUtils {
    static isSubset<T>(A: T[], B: T[]) {
        const setB = new Set(B);
        return A.every((v) => setB.has(v));
    }

    static shuffle<T>(array: T[]): T[] {
        const copy = array.slice();
        for (let i = copy.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [copy[i], copy[j]] = [copy[j], copy[i]];
        }
        return copy;
    }
}
